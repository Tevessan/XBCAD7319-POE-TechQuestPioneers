﻿namespace CampusShuttleAPI.Model
{
    public class Booking
    {
        public int Id { get; set; }
        public int ScheduleId { get; set; } // Foreign key to the Schedule entity
        public int UserId { get; set; } // Foreign key to the User entity
        public int NumberOfSeats { get; set; } = 1; // Enforce one seat per booking
        public DateTime BookingTime { get; set; } = DateTime.UtcNow; // Auto-set booking time

        // Navigation properties
        public Schedule Schedule { get; set; }
        public User User { get; set; }
    }

}
