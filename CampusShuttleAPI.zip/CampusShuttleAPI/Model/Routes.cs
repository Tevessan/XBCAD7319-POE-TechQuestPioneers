﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace CampusShuttleAPI.Model
{
    public class Routes
    {
        [Key]
        public int Id { get; set; }

        [Column("Route_Name")]
        public string RouteName { get; set; }

        [Column("Start_loc")]
        public string StartLoc { get; set; }

        [Column("End_loc")]
        public string EndLoc { get; set; }

        // Navigation property for related shuttles
        //public ICollection<Shuttle> Shuttles { get; set; }
    }
}
