﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CampusShuttleAPI.Model
{
    public class Shuttle
    {
        [Key]
        public int Id { get; set; }

        [Column("Shuttle_name")]
        public string ShuttleName { get; set; }

        [Column("Shuttle_cap")]
        public int? ShuttleCap { get; set; }

        [Column("Shuttle_available")]
        public string ShuttleAvailable { get; set; }

        [Column("RouteId")]
        public int? RouteId { get; set; }

        //public Routes Routes { get; set; }
        //public ICollection<Booking> Bookings { get; set; }
    }
}
