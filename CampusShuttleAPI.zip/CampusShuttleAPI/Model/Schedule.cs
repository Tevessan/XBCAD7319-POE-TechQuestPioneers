﻿using System.ComponentModel.DataAnnotations;

namespace CampusShuttleAPI.Model
{
    public class Schedule
    {
        [Key]
        public int Id { get; set; }
        public string? From { get; set; }
        public string? To { get; set; }
        public int? Capacity { get; set; }
        public DateTime Time { get; set; }
    }
}
