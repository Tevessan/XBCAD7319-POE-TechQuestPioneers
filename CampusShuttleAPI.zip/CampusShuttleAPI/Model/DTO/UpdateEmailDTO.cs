﻿namespace CampusShuttleAPI.Model.DTO
{
    public class UpdateEmailDTO
    {
        public string CurrentEmail { get; set; }
        public string NewEmail { get; set; }
    }
}
