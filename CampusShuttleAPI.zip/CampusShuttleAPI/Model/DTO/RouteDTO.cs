﻿namespace CampusShuttleAPI.Model.DTO
{
    public class RouteDTO
    {
        public string RouteName { get; set; }
        public string StartLoc { get; set; }
        public string EndLoc { get; set; }
    }
}
