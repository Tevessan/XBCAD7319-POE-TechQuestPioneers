﻿namespace CampusShuttleAPI.Model.DTO
{
    public class NotificationDTO
    {
        public int UserId { get; set; }
        public DateTime DateCreated { get; set; }
        public string Message { get; set; }
    }
}
