﻿namespace CampusShuttleAPI.Model.DTO
{
    public class ShuttleDTO
    {
        public string ShuttleName { get; set; }
        public int? ShuttleCap { get; set; }
        public string ShuttleAvailable { get; set; }
        public int? RouteId { get; set; }
    }
}
