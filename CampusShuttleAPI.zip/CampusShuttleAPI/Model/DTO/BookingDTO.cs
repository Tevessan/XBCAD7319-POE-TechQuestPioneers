﻿namespace CampusShuttleAPI.Model.DTO
{
    public class BookingDTO
    {
        public int ScheduleId { get; set; } 
    }
}
