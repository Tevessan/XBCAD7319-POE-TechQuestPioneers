﻿using CampusShuttleAPI.Data;
using CampusShuttleAPI.Model.DTO;
using CampusShuttleAPI.Model;
using CampusShuttleAPI.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace CampusShuttleAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly JwtService _jwtService;





        public AuthController(AppDbContext context, JwtService jwtService)
        {
            _context = context;
            _jwtService = jwtService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDTO dto)
        {
            List<string> ValidUserEmails = new List<string>
{
    "ST10090001@vcconnect.edu.za",
    "ST10090002@vcconnect.edu.za",
    "ST10090003@vcconnect.edu.za",
    "ST10090004@vcconnect.edu.za",
    "ST10090005@vcconnect.edu.za",
    "ST10090006@vcconnect.edu.za",
    "ST10090007@vcconnect.edu.za",
    "ST10090008@vcconnect.edu.za",
    "ST10090009@vcconnect.edu.za",
    "ST10090010@vcconnect.edu.za",
    "ST10090011@vcconnect.edu.za",
    "ST10090012@vcconnect.edu.za",
    "ST10090013@vcconnect.edu.za",
    "ST10090014@vcconnect.edu.za",
    "ST10090015@vcconnect.edu.za",
    "ST10090016@vcconnect.edu.za",
    "ST10090017@vcconnect.edu.za",
    "ST10090018@vcconnect.edu.za",
    "ST10090019@vcconnect.edu.za",
    "ST10090020@vcconnect.edu.za",
    "ST10090021@vcconnect.edu.za",
    "ST10090022@vcconnect.edu.za",
    "ST10090023@vcconnect.edu.za",
    "ST10090024@vcconnect.edu.za",
    "ST10090025@vcconnect.edu.za",
    "ST10090026@vcconnect.edu.za",
    "ST10090027@vcconnect.edu.za",
    "ST10090028@vcconnect.edu.za",
    "ST10090029@vcconnect.edu.za",
    "ST10090030@vcconnect.edu.za",
    "ST10090031@vcconnect.edu.za",
    "ST10090032@vcconnect.edu.za",
    "ST10090033@vcconnect.edu.za",
    "ST10090034@vcconnect.edu.za",
    "ST10090035@vcconnect.edu.za",
    "ST10090036@vcconnect.edu.za",
    "ST10090037@vcconnect.edu.za",
    "ST10090038@vcconnect.edu.za",
    "ST10090039@vcconnect.edu.za",
    "ST10090040@vcconnect.edu.za",
    "ST10090041@vcconnect.edu.za",
    "ST10090042@vcconnect.edu.za",
   "ST10091248@vcconnect.edu.za"
};
            // Check if the email is valid
            if (!ValidUserEmails.Contains(dto.Email))
            {
                return BadRequest("This email is not authorized to register.");
            }

            // Check if passwords match
            if (dto.Password != dto.ConfirmPassword)
            {
                return BadRequest("Passwords do not match");
            }

            // Check if user already exists
            if (_context.Users.Any(u => u.Email == dto.Email))
            {
                return BadRequest("User already exists");
            }

            // Hash the password
            var hashedPassword = BCrypt.Net.BCrypt.HashPassword(dto.Password);

            // Create and save the user
            var user = new User
            {
                Role = "students",
                Email = dto.Email,
                Password = hashedPassword,
                DateCreated = DateTime.UtcNow
            };

            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();

            return Ok("User registered successfully");
        }


        [HttpPost("login")]
        public IActionResult Login(LoginDTO dto)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == dto.Email);
            if (user == null || !BCrypt.Net.BCrypt.Verify(dto.Password, user.Password))
            {
                return Unauthorized("Invalid credentials");
            }

            var token = _jwtService.GenerateToken(user.Email);
            return Ok(new { Token = token });

        }
        [HttpPut("update-email")]
        public async Task<IActionResult> UpdateEmail(UpdateEmailDTO dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.CurrentEmail);
            if (user == null)
            {
                return NotFound("User not found");
            }

            if (_context.Users.Any(u => u.Email == dto.NewEmail))
            {
                return BadRequest("Email is already in use");
            }

            user.Email = dto.NewEmail;
            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return Ok("Email updated successfully");
        }

        [HttpPut("update-password")]
        public async Task<IActionResult> UpdatePassword(UpdatePasswordDTO dto)
        {
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == dto.Email);
            if (user == null)
            {
                return NotFound("User not found");
            }

            if (!BCrypt.Net.BCrypt.Verify(dto.CurrentPassword, user.Password))
            {
                return Unauthorized("Current password is incorrect");
            }

            if (dto.NewPassword != dto.ConfirmNewPassword)
            {
                return BadRequest("New passwords do not match");
            }

            user.Password = BCrypt.Net.BCrypt.HashPassword(dto.NewPassword);
            _context.Users.Update(user);
            await _context.SaveChangesAsync();

            return Ok("Password updated successfully");
        }

    }
}
