﻿using CampusShuttleAPI.Data;
using CampusShuttleAPI.Model;
using CampusShuttleAPI.Model.DTO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusShuttleAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RouteController : ControllerBase
    {
        private readonly AppDbContext _context;
        public RouteController(AppDbContext context)
        {
            _context = context;
        }
        // GET: api/Route
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Routes>>> GetRoutes()
        {
            var routes = await _context.Routes // Include Shuttles associated with each route
                .ToListAsync();
            return Ok(routes);
        }
        // GET: api/Route/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Routes>> GetRoute(int id)
        {
            var route = await _context.Routes // Include Shuttles associated with the route
                .FirstOrDefaultAsync(r => r.Id == id);
            if (route == null) return NotFound();
            return Ok(route);
        }
        // POST: api/Route
        [HttpPost]
        public async Task<ActionResult<Routes>> CreateRoute([FromBody] RouteDTO routeDTO)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var route = new Routes
            {
                RouteName = routeDTO.RouteName,
                StartLoc = routeDTO.StartLoc,
                EndLoc = routeDTO.EndLoc
            };
            _context.Routes.Add(route);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetRoute), new { id = route.Id }, route);
        }
        // PUT: api/Route/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRoute(int id, [FromBody] RouteDTO routeDTO)
        {
            var route = await _context.Routes.FindAsync(id);
            if (route == null) return NotFound();
            route.RouteName = routeDTO.RouteName;
            route.StartLoc = routeDTO.StartLoc;
            route.EndLoc = routeDTO.EndLoc;
            _context.Entry(route).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return Ok(route);
        }
        // DELETE: api/Routes/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRoute(int id)
        {
            var route = await _context.Routes.FindAsync(id);
            if (route == null) return NotFound();
            _context.Routes.Remove(route);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
