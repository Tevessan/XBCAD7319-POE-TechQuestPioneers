﻿using CampusShuttleAPI.Data;
using CampusShuttleAPI.Model;
using CampusShuttleAPI.Model.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace CampusShuttleAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingController : ControllerBase
    {
        private readonly AppDbContext _context;

        public BookingController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/Booking
        [HttpPost("book")]
        [Authorize] // Ensure the user is authenticated
        public async Task<ActionResult> BookSchedule([FromBody] BookingDTO bookingDTO)
        {
            // Extract the user's email from the JWT token
            var email = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (email == null)
            {
                return Unauthorized("User email not found in token.");
            }

            // Find the user in the database
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            if (user == null)
            {
                return Unauthorized("User not found.");
            }

            // Validate if Schedule exists
            var schedule = await _context.Schedules.FindAsync(bookingDTO.ScheduleId);
            if (schedule == null)
            {
                return NotFound($"Schedule with ID {bookingDTO.ScheduleId} not found.");
            }

            // Check if the user has already booked a seat for this schedule
            var existingBooking = await _context.Bookings
                .FirstOrDefaultAsync(b => b.ScheduleId == bookingDTO.ScheduleId && b.UserId == user.Id);
            if (existingBooking != null)
            {
                return BadRequest("You have already booked a seat for this schedule.");
            }

            schedule.Capacity = schedule.Capacity - 1;
            _context.Update(schedule);
            await _context.SaveChangesAsync();
            // Create a new Booking entity
            var booking = new Booking
            {
                ScheduleId = bookingDTO.ScheduleId,
                UserId = user.Id,
                NumberOfSeats = 1 // Enforce one seat per user
            };

            // Save the booking to the database
            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Message = "Booking successful.",
                BookingId = booking.Id,
                ScheduleId = booking.ScheduleId,
                BookingTime = booking.BookingTime
            });
        }


        [HttpGet("next-shuttle")]
        //  [Authorize]
        public async Task<ActionResult> GetNextShuttle()
        {
            var currentTimeUtc = DateTime.UtcNow;

            // Specify your local timezone
            var localTimeZone = TimeZoneInfo.FindSystemTimeZoneById("South Africa Standard Time");
            var currentTimeLocal = TimeZoneInfo.ConvertTimeFromUtc(currentTimeUtc, localTimeZone);

            // Use local time for comparison
            var nextSchedule = await _context.Schedules
                .Where(s => s.Time > currentTimeLocal)
                .OrderBy(s => s.Time)
                .FirstOrDefaultAsync();

            if (nextSchedule == null)
            {
                return NotFound("No upcoming shuttles found.");
            }

            // Convert the schedule time to local timezone for display
            var nextScheduleTimeLocal = TimeZoneInfo.ConvertTimeFromUtc(nextSchedule.Time, localTimeZone);

            return Ok(new
            {
                NextShuttle = new
                {
                    CurrentTime = currentTimeLocal,
                    ScheduleId = nextSchedule.Id,
                    From = nextSchedule.From,
                    To = nextSchedule.To,
                    Time = nextScheduleTimeLocal,
                    RemainingCapacity = ((20 - nextSchedule.Capacity) / 20.0) * 100,
                    PercentageRemaining = nextSchedule.Capacity
                }
            });

        }

        [Authorize]
        [HttpGet("get-logged-user-booking")]
        public async Task<IActionResult> GetLoggedInUserBooking()
        {
            // Extract the user's email from the JWT token
            var email = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (email == null)
            {
                return Unauthorized("User email not found in token.");
            }

            // Find the user in the database
            var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);

            if (user == null)
            {
                return Unauthorized("User not found.");
            }

            var bookedUser = await _context.Bookings.Include(e => e.Schedule).Where(e => e.UserId == user.Id).ToListAsync();
            return Ok(bookedUser);
        }



        // GET: api/Booking
        [HttpGet]
        public async Task<ActionResult> GetBookings()
        {
            var bookings = await _context.Bookings
                .Include(b => b.Schedule)
                .Include(b => b.User)
                .ToListAsync();

            if (!bookings.Any())
            {
                return NotFound("No bookings found.");
            }

            return Ok(bookings);
        }
    }
}
