﻿using CampusShuttleAPI.Data;
using CampusShuttleAPI.Model.DTO;
using CampusShuttleAPI.Model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CampusShuttleAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ShuttleController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ShuttleController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/Shuttle
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Shuttle>>> GetShuttles()
        {
            var shuttles = await _context.Shuttle
                .ToListAsync();
            return Ok(shuttles);
        }

        // GET: api/Shuttle/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Shuttle>> GetShuttle(int id)
        {
            var shuttle = await _context.Shuttle
                .FirstOrDefaultAsync(s => s.Id == id);

            if (shuttle == null) return NotFound();

            return Ok(shuttle);
        }

        // POST: api/Shuttle
        [HttpPost]
        public async Task<ActionResult<Shuttle>> CreateShuttle([FromBody] ShuttleDTO shuttleDTO)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var shuttle = new Shuttle
            {
                ShuttleName = shuttleDTO.ShuttleName,
                ShuttleCap = shuttleDTO.ShuttleCap,
                ShuttleAvailable = shuttleDTO.ShuttleAvailable,
                RouteId = shuttleDTO.RouteId
            };

            _context.Shuttle.Add(shuttle);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetShuttle), new { id = shuttle.Id }, shuttle);
        }

        // PUT: api/Shuttle/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateShuttle(int id, [FromBody] ShuttleDTO shuttleDTO)
        {
            var shuttle = await _context.Shuttle.FindAsync(id);
            if (shuttle == null) return NotFound();

            shuttle.ShuttleName = shuttleDTO.ShuttleName;
            shuttle.ShuttleCap = shuttleDTO.ShuttleCap;
            shuttle.ShuttleAvailable = shuttleDTO.ShuttleAvailable;
            shuttle.RouteId = shuttleDTO.RouteId;

            _context.Entry(shuttle).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return Ok(shuttle);
        }

        // DELETE: api/Shuttle/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteShuttle(int id)
        {
            var shuttle = await _context.Shuttle.FindAsync(id);
            if (shuttle == null) return NotFound();

            _context.Shuttle.Remove(shuttle);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}

