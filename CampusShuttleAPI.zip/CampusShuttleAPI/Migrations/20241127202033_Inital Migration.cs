﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace CampusShuttleAPI.Migrations
{
    /// <inheritdoc />
    public partial class InitalMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Notifications",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: true),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true),
                    Message = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsRead = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Notifications", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Routes",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Route_Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Start_loc = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    End_loc = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Routes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Schedules",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    From = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    To = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Capacity = table.Column<int>(type: "int", nullable: true),
                    Time = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Schedules", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Shuttle",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Shuttle_name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Shuttle_cap = table.Column<int>(type: "int", nullable: true),
                    Shuttle_available = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    RouteId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Shuttle", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Password = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Role = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateCreated = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Bookings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ScheduleId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false),
                    NumberOfSeats = table.Column<int>(type: "int", nullable: false),
                    BookingTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bookings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Bookings_Schedules_ScheduleId",
                        column: x => x.ScheduleId,
                        principalTable: "Schedules",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Bookings_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Schedules",
                columns: new[] { "Id", "Capacity", "From", "Time", "To" },
                values: new object[,]
                {
                    { 1, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 7, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 2, 20, "Varsity College", new DateTime(2024, 11, 28, 7, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 3, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 8, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 4, 20, "Varsity College", new DateTime(2024, 11, 28, 8, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 5, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 8, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 6, 20, "Varsity College", new DateTime(2024, 11, 28, 8, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 7, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 9, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 8, 20, "Varsity College", new DateTime(2024, 11, 28, 9, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 9, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 9, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 10, 20, "Varsity College", new DateTime(2024, 11, 28, 9, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 11, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 10, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 12, 20, "Varsity College", new DateTime(2024, 11, 28, 10, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 13, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 10, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 14, 20, "Varsity College", new DateTime(2024, 11, 28, 10, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 15, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 11, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 16, 20, "Varsity College", new DateTime(2024, 11, 28, 11, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 17, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 11, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 18, 20, "Varsity College", new DateTime(2024, 11, 28, 11, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 19, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 12, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 20, 20, "Varsity College", new DateTime(2024, 11, 28, 12, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 21, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 12, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 22, 20, "Varsity College", new DateTime(2024, 11, 28, 12, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 23, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 13, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 24, 20, "Varsity College", new DateTime(2024, 11, 28, 13, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 25, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 13, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 26, 20, "Varsity College", new DateTime(2024, 11, 28, 13, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 27, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 14, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 28, 20, "Varsity College", new DateTime(2024, 11, 28, 14, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 29, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 14, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 30, 20, "Varsity College", new DateTime(2024, 11, 28, 14, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 31, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 15, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 32, 20, "Varsity College", new DateTime(2024, 11, 28, 15, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 33, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 15, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 34, 20, "Varsity College", new DateTime(2024, 11, 28, 15, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 35, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 16, 0, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 36, 20, "Varsity College", new DateTime(2024, 11, 28, 16, 0, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" },
                    { 37, 20, "Sandton Gautrain Station", new DateTime(2024, 11, 28, 16, 30, 0, 0, DateTimeKind.Unspecified), "Varsity College" },
                    { 38, 20, "Varsity College", new DateTime(2024, 11, 28, 16, 30, 0, 0, DateTimeKind.Unspecified), "Sandton Gautrain Station" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_ScheduleId",
                table: "Bookings",
                column: "ScheduleId");

            migrationBuilder.CreateIndex(
                name: "IX_Bookings_UserId",
                table: "Bookings",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Bookings");

            migrationBuilder.DropTable(
                name: "Notifications");

            migrationBuilder.DropTable(
                name: "Routes");

            migrationBuilder.DropTable(
                name: "Shuttle");

            migrationBuilder.DropTable(
                name: "Schedules");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
