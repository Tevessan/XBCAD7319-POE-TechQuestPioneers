﻿using CampusShuttleAPI.Model;
using Microsoft.EntityFrameworkCore;

namespace CampusShuttleAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }
        public DbSet<User> Users { get; set; }
        public DbSet<Shuttle> Shuttle { get; set; }
        public DbSet<Routes> Routes { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Schedule> Schedules { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            var schedules = new List<Schedule>
    {
        new Schedule { Id = 1, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 7, 30, 0) },
        new Schedule { Id = 2, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 7, 30, 0) },
        new Schedule { Id = 3, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 8, 0, 0) },
        new Schedule { Id = 4, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 8, 0, 0) },
        new Schedule { Id = 5, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 8, 30, 0) },
        new Schedule { Id = 6, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 8, 30, 0) },
        new Schedule { Id = 7, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 9, 0, 0) },
        new Schedule { Id = 8, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 9, 0, 0) },
        new Schedule { Id = 9, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 9, 30, 0) },
        new Schedule { Id = 10, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 9, 30, 0) },
        new Schedule { Id = 11, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 10, 0, 0) },
        new Schedule { Id = 12, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 10, 0, 0) },
        new Schedule { Id = 13, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 10, 30, 0) },
        new Schedule { Id = 14, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 10, 30, 0) },
        new Schedule { Id = 15, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 11, 0, 0) },
        new Schedule { Id = 16, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 11, 0, 0) },
        new Schedule { Id = 17, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 11, 30, 0) },
        new Schedule { Id = 18, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 11, 30, 0) },
        new Schedule { Id = 19, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 12, 0, 0) },
        new Schedule { Id = 20, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 12, 0, 0) },
        new Schedule { Id = 21, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 12, 30, 0) },
        new Schedule { Id = 22, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 12, 30, 0) },
        new Schedule { Id = 23, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 13, 0, 0) },
        new Schedule { Id = 24, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 13, 0, 0) },
        new Schedule { Id = 25, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 13, 30, 0) },
        new Schedule { Id = 26, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 13, 30, 0) },
        new Schedule { Id = 27, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 14, 0, 0) },
        new Schedule { Id = 28, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 14, 0, 0) },
        new Schedule { Id = 29, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 14, 30, 0) },
        new Schedule { Id = 30, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 14, 30, 0) },
        new Schedule { Id = 31, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 15, 0, 0) },
        new Schedule { Id = 32, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 15, 0, 0) },
        new Schedule { Id = 33, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 15, 30, 0) },
        new Schedule { Id = 34, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 15, 30, 0) },
        new Schedule { Id = 35, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 16, 0, 0) },
        new Schedule { Id = 36, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 16, 0, 0) },
        new Schedule { Id = 37, From = "Sandton Gautrain Station", To = "Varsity College", Capacity = 20, Time = new DateTime(2024, 11, 28, 16, 30, 0) },
        new Schedule { Id = 38, From = "Varsity College", To = "Sandton Gautrain Station", Capacity = 20, Time = new DateTime(2024, 11, 28, 16, 30, 0) }
    };

            modelBuilder.Entity<Schedule>().HasData(schedules);
        }





    }
}
