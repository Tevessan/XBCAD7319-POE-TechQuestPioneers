package com.example.campusshuttleconnect

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.campusshuttleconnect.R

class NotificationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)

        // You can add logic here to dynamically load notifications if needed
    }
}
