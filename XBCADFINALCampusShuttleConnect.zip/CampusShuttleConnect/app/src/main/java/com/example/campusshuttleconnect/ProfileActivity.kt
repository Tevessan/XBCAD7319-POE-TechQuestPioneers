package com.example.campusshuttleconnect

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import javax.net.ssl.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var etCurrentEmail: EditText
    private lateinit var etNewEmail: EditText
    private lateinit var etPasswordEmail: EditText // Added for password update email
    private lateinit var etOldPassword: EditText
    private lateinit var etNewPassword: EditText
    private lateinit var etConfirmPassword: EditText
    private lateinit var btnChangeEmail: Button
    private lateinit var btnChangePassword: Button
    private val client = getUnsafeOkHttpClient() // Use unsafe client for development only

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        // Initialize views
        etCurrentEmail = findViewById(R.id.et_current_email)
        etNewEmail = findViewById(R.id.et_new_email)
        etPasswordEmail = findViewById(R.id.et_password_email) // For password email
        etOldPassword = findViewById(R.id.et_old_password)
        etNewPassword = findViewById(R.id.et_new_password)
        etConfirmPassword = findViewById(R.id.et_confirm_password)
        btnChangeEmail = findViewById(R.id.btn_change_email)
        btnChangePassword = findViewById(R.id.btn_change_password)

        // Menu Icon Click Event
        val homeIcon = findViewById<ImageView>(R.id.homeIcon)
        homeIcon.setOnClickListener {
            val intent = Intent(this, SchedulePageActivity::class.java)
            startActivity(intent)
        }
        // Menu Icon Click Event
        val profileIcon = findViewById<ImageView>(R.id.profileIcon)
        profileIcon.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        // Menu Icon Click Event
        val SettingsIcon = findViewById<ImageView>(R.id.searchIcon)
        SettingsIcon.setOnClickListener {
            val intent = Intent(this, BookingReportActivity::class.java)
            startActivity(intent)
        }

        // Handle change email click
        btnChangeEmail.setOnClickListener {
            val currentEmail = etCurrentEmail.text.toString().trim()
            val newEmail = etNewEmail.text.toString().trim()

            if (validateEmailInput(currentEmail, newEmail)) {
                changeEmail(currentEmail, newEmail)
            }
        }

        // Handle change password click
        btnChangePassword.setOnClickListener {
            val email = etPasswordEmail.text.toString().trim()
            val oldPassword = etOldPassword.text.toString().trim()
            val newPassword = etNewPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            if (validatePasswordInput(email, oldPassword, newPassword, confirmPassword)) {
                changePassword(email, oldPassword, newPassword, confirmPassword)
            }
        }
    }

    // API call to update email
    private fun changeEmail(currentEmail: String, newEmail: String) {
        val json = """
            {
                "currentEmail": "$currentEmail",
                "newEmail": "$newEmail"
            }
        """.trimIndent()
        val requestBody = json.toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://shuttlenew-hpcqc7e9fhf3gacb.southafricanorth-01.azurewebsites.net/api/auth/update-email") // Replace with your API endpoint
            .put(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { showToast("Failed to change email: ${e.message}") }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        showToast("Email updated successfully")
                    } else {
                        showToast("Failed to update email: ${response.message}")
                    }
                }
            }
        })
    }

    // API call to update password
    private fun changePassword(email: String, currentPassword: String, newPassword: String, confirmNewPassword: String) {
        val json = """
            {
                "email": "$email",
                "currentPassword": "$currentPassword",
                "newPassword": "$newPassword",
                "confirmNewPassword": "$confirmNewPassword"
            }
        """.trimIndent()
        val requestBody = json.toRequestBody("application/json; charset=utf-8".toMediaType())

        val request = Request.Builder()
            .url("https://shuttlenew-hpcqc7e9fhf3gacb.southafricanorth-01.azurewebsites.net/api/auth/update-password") // Replace with your API endpoint
            .put(requestBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { showToast("Failed to change password: ${e.message}") }
            }

            override fun onResponse(call: Call, response: Response) {
                runOnUiThread {
                    if (response.isSuccessful) {
                        showToast("Password updated successfully")
                    } else {
                        showToast("Failed to update password: ${response.message}")
                    }
                }
            }
        })
    }

    // Validate email inputs
    private fun validateEmailInput(currentEmail: String, newEmail: String): Boolean {
        return when {
            currentEmail.isEmpty() -> {
                showToast("Current email cannot be empty")
                false
            }
            newEmail.isEmpty() -> {
                showToast("New email cannot be empty")
                false
            }
            !android.util.Patterns.EMAIL_ADDRESS.matcher(newEmail).matches() -> {
                showToast("New email format is invalid")
                false
            }
            else -> true
        }
    }

    // Validate password inputs
    private fun validatePasswordInput(email: String, currentPassword: String, newPassword: String, confirmNewPassword: String): Boolean {
        return when {
            email.isEmpty() -> {
                showToast("Email cannot be empty")
                false
            }
            currentPassword.isEmpty() -> {
                showToast("Current password cannot be empty")
                false
            }
            newPassword.isEmpty() -> {
                showToast("New password cannot be empty")
                false
            }
            confirmNewPassword.isEmpty() -> {
                showToast("Please confirm your new password")
                false
            }
            newPassword != confirmNewPassword -> {
                showToast("New passwords do not match")
                false
            }
            newPassword.length < 6 -> {
                showToast("Password must be at least 6 characters long")
                false
            }
            else -> true
        }
    }

    // Helper to show toast messages
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // Unsafe OkHttp client for development (Allow self-signed certificates)
    private fun getUnsafeOkHttpClient(): OkHttpClient {
        return try {
            val trustAllCerts = arrayOf<TrustManager>(
                object : X509TrustManager {
                    override fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {}
                    override fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>, authType: String) {}
                    override fun getAcceptedIssuers(): Array<java.security.cert.X509Certificate> = arrayOf()
                }
            )

            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, java.security.SecureRandom())
            val sslSocketFactory = sslContext.socketFactory

            OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
                .hostnameVerifier { _, _ -> true }
                .build()
        } catch (e: Exception) {
            throw RuntimeException(e)
        }

    }

}
