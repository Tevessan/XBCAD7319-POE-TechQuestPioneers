package com.example.campusshuttleconnect

import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.maps.android.PolyUtil
import kotlinx.coroutines.*
import org.json.JSONException
import org.json.JSONObject
import java.net.URL

class ShuttleTrackingPageActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var googleMap: GoogleMap

    // Varsity College Sandton and Sandton Gautrain Station Coordinates
    private val varsityCollegeLocation = LatLng(-26.0936, 28.0477)
    private val sandtonGautrainLocation = LatLng(-26.10794372694716, 28.057202856105523)

    private var routeCoordinatesToCampus = listOf<LatLng>() // Varsity to Gautrain
    private var routeCoordinatesToGautrain = listOf<LatLng>() // Gautrain to Varsity

    private lateinit var movingMarkerToCampus: Marker
    private lateinit var movingMarkerToGautrain: Marker
    private lateinit var labelMarkerToCampus: Marker
    private lateinit var labelMarkerToGautrain: Marker

    private val stepIntervalMillis = 30L // Update interval in milliseconds

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Handle edge-to-edge UI adjustments
        ViewCompat.setOnApplyWindowInsetsListener(findViewById<View>(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize Google Maps using SupportMapFragment
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this) // Load the map asynchronously
    }

    override fun onMapReady(googleMap: GoogleMap) {
        this.googleMap = googleMap

        // Enable zoom controls
        googleMap.uiSettings.isZoomControlsEnabled = true

        // Add static markers for Varsity College Sandton and Gautrain Station
        googleMap.addMarker(
            MarkerOptions()
                .position(varsityCollegeLocation)
                .title("Varsity College Sandton")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
        )

        googleMap.addMarker(
            MarkerOptions()
                .position(sandtonGautrainLocation)
                .title("Sandton Gautrain Station")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_YELLOW))
        )

        // Fetch both routes
        fetchRoute(varsityCollegeLocation, sandtonGautrainLocation) { route ->
            routeCoordinatesToGautrain = route ?: emptyList()
            setupMarkersAndPath()
        }

        fetchRoute(sandtonGautrainLocation, varsityCollegeLocation) { route ->
            routeCoordinatesToCampus = route ?: emptyList()
            setupMarkersAndPath()
        }
    }

    private fun fetchRoute(origin: LatLng, destination: LatLng, callback: (List<LatLng>?) -> Unit) {
        val originString = "${origin.latitude},${origin.longitude}"
        val destinationString = "${destination.latitude},${destination.longitude}"

        // Replace "YOUR_API_KEY" with your actual Google Directions API key
        val apiKey = "AIzaSyCsRj3LZPeiEJa0wW9BO6MA91EoGktzv1k"

        val url =
            "https://maps.googleapis.com/maps/api/directions/json?origin=$originString&destination=$destinationString&key=$apiKey"

        // Use coroutines for asynchronous network call
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val result = URL(url).readText()

                // Parse the result to get route points
                val routePoints = parseRoute(result)

                withContext(Dispatchers.Main) {
                    callback(routePoints)
                }
            } catch (e: Exception) {
                e.printStackTrace()
                withContext(Dispatchers.Main) {
                    callback(null)
                }
            }
        }
    }

    private fun parseRoute(jsonResult: String): List<LatLng>? {
        try {
            val jsonObject = JSONObject(jsonResult)
            val routes = jsonObject.getJSONArray("routes")
            if (routes.length() > 0) {
                val route = routes.getJSONObject(0)
                val overviewPolyline = route.getJSONObject("overview_polyline")
                val encodedPoints = overviewPolyline.getString("points")
                // Decode polyline into a list of LatLng points
                return PolyUtil.decode(encodedPoints)
            } else {
                return null
            }
        } catch (e: JSONException) {
            e.printStackTrace()
            return null
        }
    }

    private fun setupMarkersAndPath() {
        if (routeCoordinatesToGautrain.isNotEmpty() && routeCoordinatesToCampus.isNotEmpty()) {
            // Draw both routes
            drawPolyLineOnMap(routeCoordinatesToGautrain, Color.RED)
            drawPolyLineOnMap(routeCoordinatesToCampus, Color.BLUE)

            // Add moving markers for both shuttle routes with titles
            movingMarkerToGautrain = googleMap.addMarker(
                MarkerOptions()
                    .position(routeCoordinatesToGautrain[0])
                    .title("Shuttle 1")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
            )!!

            movingMarkerToCampus = googleMap.addMarker(
                MarkerOptions()
                    .position(routeCoordinatesToCampus[0])
                    .title("Shuttle 2")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
            )!!

            // Add labels above moving markers with initial times
            labelMarkerToGautrain = googleMap.addMarker(
                MarkerOptions()
                    .position(routeCoordinatesToGautrain[0])
                    .icon(createTextIcon("10 minutes away"))
                    .anchor(0.5f, 1.5f)
            )!!

            labelMarkerToCampus = googleMap.addMarker(
                MarkerOptions()
                    .position(routeCoordinatesToCampus[0])
                    .icon(createTextIcon("7 minutes away"))
                    .anchor(0.5f, 1.5f)
            )!!

            // *Calculate bounds to include all markers and routes*
            val boundsBuilder = LatLngBounds.Builder()
            for (point in routeCoordinatesToGautrain) {
                boundsBuilder.include(point)
            }
            for (point in routeCoordinatesToCampus) {
                boundsBuilder.include(point)
            }
            boundsBuilder.include(varsityCollegeLocation)
            boundsBuilder.include(sandtonGautrainLocation)
            val bounds = boundsBuilder.build()

            // *Move the camera to the calculated bounds*
            googleMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))

            // Start animations for both shuttles with specific travel times
            animateMarkerAlongRoute(
                movingMarkerToGautrain,
                routeCoordinatesToGautrain,
                labelMarkerToGautrain,
                "Shuttle to Gautrain",
                10 // Red marker starts from 10 minutes
            )

            animateMarkerAlongRoute(
                movingMarkerToCampus,
                routeCoordinatesToCampus,
                labelMarkerToCampus,
                "Shuttle to Campus",
                7 // Green marker starts from 7 minutes
            )
        }
    }

    private fun drawPolyLineOnMap(list: List<LatLng>, color: Int) {
        val polyOptions = PolylineOptions().apply {
            this.color(color)
            width(5f)
            addAll(list)
        }

        googleMap.addPolyline(polyOptions)
    }

    private fun createTextIcon(text: String): BitmapDescriptor {
        val paint = Paint().apply {
            color = Color.BLACK
            textSize = 50f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)

        val bitmap = Bitmap.createBitmap(bounds.width() + 20, bounds.height() + 20, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawText(text, (bitmap.width / 2).toFloat(), (bitmap.height / 1.5f), paint)
        return BitmapDescriptorFactory.fromBitmap(bitmap)
    }

    private fun animateMarkerAlongRoute(
        marker: Marker,
        route: List<LatLng>,
        labelMarker: Marker,
        labelText: String,
        travelTimeMinutes: Int
    ) {
        val handler = Handler(Looper.getMainLooper())
        val totalSteps = (travelTimeMinutes * 60 * 1000 / stepIntervalMillis).toInt()
        var step = 0

        handler.post(object : Runnable {
            override fun run() {
                if (step <= totalSteps) {
                    val fraction = step.toFloat() / totalSteps
                    val nextPosition = interpolatePosition(route, fraction)
                    marker.position = nextPosition

                    // Calculate remaining time in minutes
                    val remainingTime = ((totalSteps - step) * stepIntervalMillis / 60000).toInt()

                    // Update label position and text
                    labelMarker.position = LatLng(nextPosition.latitude + 0.0001, nextPosition.longitude)
                    labelMarker.setIcon(createTextIcon("$remainingTime minutes away"))

                    step++
                    handler.postDelayed(this, stepIntervalMillis)
                } else {
                    // Reset animation for the next trip
                    step = 0
                    handler.post(this)
                }
            }
        })
    }

    private fun interpolatePosition(route: List<LatLng>, fraction: Float): LatLng {
        if (fraction >= 1f) return route.last()

        // Calculate the total distance of the route
        val totalDistance = calculateTotalDistance(route)

        // Distance to travel based on fraction
        val distanceToTravel = totalDistance * fraction

        var distanceCovered = 0f

        for (i in 0 until route.size - 1) {
            val segmentDistance = distanceBetween(route[i], route[i + 1])

            if (distanceCovered + segmentDistance >= distanceToTravel) {
                val remainingDistance = distanceToTravel - distanceCovered
                val segmentFraction = remainingDistance / segmentDistance

                val lat = route[i].latitude + (route[i + 1].latitude - route[i].latitude) * segmentFraction
                val lng = route[i].longitude + (route[i + 1].longitude - route[i].longitude) * segmentFraction

                return LatLng(lat, lng)
            } else {
                distanceCovered += segmentDistance
            }
        }

        return route.last()
    }

    private fun calculateTotalDistance(route: List<LatLng>): Float {
        var totalDistance = 0f
        for (i in 0 until route.size - 1) {
            totalDistance += distanceBetween(route[i], route[i + 1])
        }
        return totalDistance
    }

    private fun distanceBetween(point1: LatLng, point2: LatLng): Float {
        val results = FloatArray(1)
        android.location.Location.distanceBetween(
            point1.latitude, point1.longitude,
            point2.latitude, point2.longitude,
            results
        )
        return results[0]
        }
}