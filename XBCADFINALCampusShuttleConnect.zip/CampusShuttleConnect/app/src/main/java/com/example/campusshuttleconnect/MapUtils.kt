package com.example.campusshuttleconnect

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.google.android.gms.maps.model.LatLng
import java.lang.Math.toDegrees
import kotlin.math.abs
import kotlin.math.atan

class MapUtils  {


    // Function to return the path between Varsity College Sandton and Sandton Gautrain Station


    fun getLocations(): ArrayList<LatLng> {
        val locationList = ArrayList<LatLng>()

        // Varsity College Sandton coordinates
        locationList.add(LatLng(-26.103056, 28.053611)) // Starting Point: Varsity College Sandton

        // Add intermediate points if needed (optional)
        locationList.add(LatLng(-26.101234, 28.056789)) // Example midpoint

        // Sandton Gautrain Station coordinates
        locationList.add(LatLng(-26.1075, 28.056944)) // Destination: Sandton Gautrain Station

        return locationList
    }
    companion object {
    fun getBitmap(context: Context): Bitmap {
        return BitmapFactory.decodeResource(context.resources, R.drawable.bus_marker) // Replace with your car icon resource
    }
    // Function to create a bitmap for starting location


        fun getStartingLocationBitmap(): Bitmap {
            val height = 40
            val width = 40
            val bitmap = Bitmap.createBitmap(height, width, Bitmap.Config.RGB_565)
            val canvas = Canvas(bitmap)
            val paint = Paint()
            paint.color = Color.BLUE // Change color for the starting location marker
            paint.style = Paint.Style.FILL
            paint.isAntiAlias = true
            canvas.drawCircle(width / 2f, height / 2f, (width / 2f), paint) // Draw a circle
            return bitmap
        }
    }

    // Function to calculate the rotation angle for the car icon

    fun getCarRotation(startLL: LatLng, endLL: LatLng): Float {
        val latDifference = abs(startLL.latitude - endLL.latitude)
        val lngDifference = abs(startLL.longitude - endLL.longitude)
        var rotation = -1F
        when {
            startLL.latitude < endLL.latitude && startLL.longitude < endLL.longitude -> {
                rotation = toDegrees(atan(lngDifference / latDifference)).toFloat()
            }
            startLL.latitude >= endLL.latitude && startLL.longitude < endLL.longitude -> {
                rotation = (90 - toDegrees(atan(lngDifference / latDifference)) + 90).toFloat()
            }
            startLL.latitude >= endLL.latitude && startLL.longitude >= endLL.longitude -> {
                rotation = (toDegrees(atan(lngDifference / latDifference)) + 180).toFloat()
            }
            startLL.latitude < endLL.latitude && startLL.longitude >= endLL.longitude -> {
                rotation = (90 - toDegrees(atan(lngDifference / latDifference)) + 270).toFloat()
            }
        }
        return rotation
    }




    }
