package com.example.campusshuttleconnect

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import okhttp3.*
import java.io.IOException
import java.security.cert.X509Certificate
import javax.net.ssl.*

data class Booking(
    val id: Int = 0,
    val scheduleId: Int = 0,
    val numberOfSeats: Int = 0,
    val bookingTime: String = "",
    val schedule: Schedule? = null // Nullable for safety
)

data class Schedule(
    val id: Int = 0,
    val from: String = "",
    val to: String = "",
    val capacity: Int = 0,
    val time: String = ""
)

data class NextShuttle(
    val scheduleId: Int = 0,
    val from: String = "",
    val to: String = "",
    val time: String = "",
    val remainingCapacity: Int = 0,
    val percentageRemaining: Int = 0
)

data class NextShuttleResponse(
    val nextShuttle: NextShuttle
)

class SchedulePageActivity : AppCompatActivity() {

    private lateinit var shuttleCapacityProgress: ProgressBar
    private lateinit var shuttleCapacityPercentage: TextView
    private lateinit var bookingsListView: ListView

    private val nextShuttleUrl = "https://shuttlenew-hpcqc7e9fhf3gacb.southafricanorth-01.azurewebsites.net/api/Booking/next-shuttle"
    private val bookingsUrl = "https://shuttlenew-hpcqc7e9fhf3gacb.southafricanorth-01.azurewebsites.net/api/Booking/get-logged-user-booking"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_schedule_page)

        shuttleCapacityProgress = findViewById(R.id.shuttleCapacityProgress)
        shuttleCapacityPercentage = findViewById(R.id.shuttleCapacityPercentage)
        bookingsListView = findViewById(R.id.bookingsListView)
        val menuIcon: ImageView = findViewById(R.id.menuIcon)

        menuIcon.setOnClickListener {
            val intent = Intent(this, SideMenuActivity::class.java)
            startActivity(intent)
        }
// Menu Icon Click Event
        val homeIcon = findViewById<ImageView>(R.id.homeIcon)
        homeIcon.setOnClickListener {
            val intent = Intent(this, SchedulePageActivity::class.java)
            startActivity(intent)
        }
        // Menu Icon Click Event
        val profileIcon = findViewById<ImageView>(R.id.profileIcon)
        profileIcon.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        // Menu Icon Click Event
        val SettingsIcon = findViewById<ImageView>(R.id.searchIcon)
        SettingsIcon.setOnClickListener {
            val intent = Intent(this, BookingReportActivity::class.java)
            startActivity(intent)
        }
        fetchNextShuttleData()
        fetchUserBookings()
    }

    private fun fetchNextShuttleData() {
        val client = getUnsafeOkHttpClient()
        val request = Request.Builder().url(nextShuttleUrl).get().build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@SchedulePageActivity, "Failed to fetch next shuttle: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    runOnUiThread {
                        Toast.makeText(this@SchedulePageActivity, "Error: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }

                response.body?.let {
                    val responseBody = it.string()
                    Log.d("NextShuttleResponse", responseBody) // Log the response for debugging
                    try {
                        val gson = Gson()
                        val nextShuttleResponse = gson.fromJson(responseBody, NextShuttleResponse::class.java)

                        runOnUiThread {
                            updateNextShuttleUI(nextShuttleResponse.nextShuttle)
                        }
                    } catch (e: JsonSyntaxException) {
                        Log.e("NextShuttleResponse", "Invalid JSON format: ${e.message}")
                        runOnUiThread {
                            Toast.makeText(this@SchedulePageActivity, "Invalid shuttle data", Toast.LENGTH_SHORT).show()
                        }
                    }
                } ?: runOnUiThread {
                    Toast.makeText(this@SchedulePageActivity, "No response body received", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun updateNextShuttleUI(nextShuttle: NextShuttle) {
        shuttleCapacityProgress.progress = nextShuttle.percentageRemaining
        shuttleCapacityPercentage.text = "${nextShuttle.percentageRemaining}"
    }

    private fun fetchUserBookings() {
        val client = getUnsafeOkHttpClient()
        val token = getUserToken()

        val request = Request.Builder()
            .url(bookingsUrl)
            .addHeader("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread {
                    Toast.makeText(this@SchedulePageActivity, "Failed to fetch bookings: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onResponse(call: Call, response: Response) {
                if (!response.isSuccessful) {
                    runOnUiThread {
                        Toast.makeText(this@SchedulePageActivity, "Error: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                    return
                }

                response.body?.let {
                    val responseBody = it.string()
                    Log.d("UserBookingsResponse", responseBody) // Log the response for debugging
                    try {
                        val gson = Gson()
                        val bookings = gson.fromJson(responseBody, Array<Booking>::class.java)

                        // Filter out any null or invalid data before updating the UI
                        val validBookings = bookings.filter { booking ->
                            booking.schedule != null
                        }

                        runOnUiThread {
                            updateBookingsList(validBookings.toTypedArray())
                        }
                    } catch (e: JsonSyntaxException) {
                        Log.e("UserBookingsResponse", "Invalid JSON format: ${e.message}")
                        runOnUiThread {
                            Toast.makeText(this@SchedulePageActivity, "Invalid booking data", Toast.LENGTH_SHORT).show()
                        }
                    }
                } ?: runOnUiThread {
                    Toast.makeText(this@SchedulePageActivity, "No response body received", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }

    private fun updateBookingsList(bookings: Array<Booking>) {
        val bookingDetails = bookings.map {
            val from = it.schedule?.from ?: "Unknown"
            val to = it.schedule?.to ?: "Unknown"
            val time = it.schedule?.time ?: "Unknown"
            val seats = it.numberOfSeats

            "From: $from\nTo: $to\nTime: $time\nSeats: $seats"
        }

        // Use a custom layout for the ListView items to ensure consistent text color
        val adapter = ArrayAdapter(this, R.layout.custom_list_item, bookingDetails)
        bookingsListView.adapter = adapter
    }

    private fun getUserToken(): String {
        val sharedPref = getSharedPreferences("user_prefs", MODE_PRIVATE)
        return sharedPref.getString("jwt_token", "") ?: ""
    }

    private fun getUnsafeOkHttpClient(): OkHttpClient {
        val trustAllCerts = arrayOf<TrustManager>(
            object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate?>?, authType: String?) {}
                override fun checkServerTrusted(chain: Array<X509Certificate?>?, authType: String?) {}
                override fun getAcceptedIssuers(): Array<X509Certificate?>? = arrayOfNulls(0)
            }
        )

        val sslContext = SSLContext.getInstance("SSL")
        sslContext.init(null, trustAllCerts, java.security.SecureRandom())

        return OkHttpClient.Builder()
            .sslSocketFactory(sslContext.socketFactory, trustAllCerts[0] as X509TrustManager)
            .hostnameVerifier { _, _ -> true }
            .build()
    }

}
