package com.example.campusshuttleconnect

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.security.cert.X509Certificate
import javax.net.ssl.*

class BookingReportActivity : AppCompatActivity() {

    private val client = getUnsafeOkHttpClient() // Use unsafe client for development
    private lateinit var schedulesListView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val schedules = mutableListOf<JSONObject>()

    private val CHANNEL_ID = "booking_notification_channel"
    private val NOTIFICATION_ID = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking_report)

        val menuIcon: ImageView = findViewById(R.id.menuIcon)
        menuIcon.setOnClickListener {
            val intent = Intent(this, SideMenuActivity::class.java)
            startActivity(intent)
        }

        // Menu Icon Click Event
        val homeIcon = findViewById<ImageView>(R.id.homeIcon)
        homeIcon.setOnClickListener {
            val intent = Intent(this, SchedulePageActivity::class.java)
            startActivity(intent)
        }
        // Menu Icon Click Event
        val profileIcon = findViewById<ImageView>(R.id.profileIcon)
        profileIcon.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }
        // Menu Icon Click Event
        val SettingsIcon = findViewById<ImageView>(R.id.searchIcon)
        SettingsIcon.setOnClickListener {
            val intent = Intent(this, BookingReportActivity::class.java)
            startActivity(intent)
        }

        setupNotificationChannel() // Initialize the notification channel
        setupUI()
        fetchSchedules()
    }

    private fun setupUI() {
        // Handle window insets for proper layout adjustment
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize the ListView and adapter with a custom layout
        schedulesListView = findViewById(R.id.schedulesListView)
        adapter = ArrayAdapter(this, R.layout.custom_list_item, mutableListOf())
        schedulesListView.adapter = adapter

        // Set a click listener for list items to handle bookings
        schedulesListView.setOnItemClickListener { _, _, position, _ ->
            val selectedSchedule = schedules[position]
            val scheduleId = selectedSchedule.getInt("id")
            bookSchedule(scheduleId)
        }
    }

    private fun setupNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Booking Notifications"
            val descriptionText = "Notifications for successful bookings"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun fetchSchedules() {
        val url = "https://shuttlenew-hpcqc7e9fhf3gacb.southafricanorth-01.azurewebsites.net/api/Schedule"
        val request = Request.Builder().url(url).get().build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                logErrorAndShowToast("Failed to fetch schedules: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    response.body?.string()?.let { responseBody ->
                        val jsonArray = JSONArray(responseBody)
                        updateSchedulesList(jsonArray)
                    } ?: logErrorAndShowToast("No response body received.")
                } else {
                    logErrorAndShowToast("Failed to fetch schedules: ${response.code}")
                }
            }
        })
    }

    private fun updateSchedulesList(jsonArray: JSONArray) {
        runOnUiThread {
            schedules.clear()
            adapter.clear()

            for (i in 0 until jsonArray.length()) {
                val schedule = jsonArray.getJSONObject(i)
                schedules.add(schedule)

                val displayText =
                    "${schedule.getString("from")} to ${schedule.getString("to")} at ${schedule.getString("time")} (Capacity: ${schedule.getInt("capacity")})"
                adapter.add(displayText)
            }

            adapter.notifyDataSetChanged()
        }
    }

    private fun bookSchedule(scheduleId: Int) {
        val url =
            "https://shuttlenew-hpcqc7e9fhf3gacb.southafricanorth-01.azurewebsites.net/api/Booking/book"
        val token = getToken()

        if (token == null) {
            showToast("JWT Token not found. Please log in again.")
            return
        }

        val jsonObject = JSONObject().apply {
            put("scheduleId", scheduleId)
        }

        val body = RequestBody.create(
            "application/json; charset=utf-8".toMediaTypeOrNull(),
            jsonObject.toString()
        )
        val request = Request.Builder()
            .url(url)
            .addHeader("Authorization", "Bearer $token")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                logErrorAndShowToast("Booking failed: ${e.message}")
            }

            override fun onResponse(call: Call, response: Response) {
                if (response.isSuccessful) {
                    val selectedSchedule = schedules.firstOrNull { it.getInt("id") == scheduleId }
                    val selectedTime = selectedSchedule?.getString("time") ?: "Unknown Time"
                    val selectedDirection =
                        "${selectedSchedule?.getString("from")} to ${selectedSchedule?.getString("to")}"

                    runOnUiThread {
                        // Show success toast
                        showToast("Booking successful!")

                        // Show notification
                        showBookingNotification(selectedTime, selectedDirection)

                        // Navigate to SuccessfulBookingActivity
                        val intent = Intent(
                            this@BookingReportActivity,
                            SuccessfulBookingActivity::class.java
                        ).apply {
                            putExtra("selected_time", selectedTime)
                            putExtra("selected_direction", selectedDirection)
                        }
                        startActivity(intent)
                        finish()
                    }
                } else {
                    logErrorAndShowToast("Booking failed: ${response.code}")
                }
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun showBookingNotification(selectedTime: String, selectedDirection: String) {
        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_check_circle)
            .setContentTitle("Booking Confirmed!")
            .setContentText("Your booking from $selectedDirection at $selectedTime is confirmed.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        with(NotificationManagerCompat.from(this)) {
            notify(NOTIFICATION_ID, notificationBuilder.build())
        }
    }

    private fun getToken(): String? {
        val sharedPref = getSharedPreferences("user_prefs", MODE_PRIVATE)
        return sharedPref.getString("jwt_token", null)
    }

    private fun logErrorAndShowToast(message: String) {
        Log.e("BookingReportActivity", message)
        runOnUiThread {
            Toast.makeText(this@BookingReportActivity, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showToast(message: String) {
        runOnUiThread {
            Toast.makeText(this@BookingReportActivity, message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun getUnsafeOkHttpClient(): OkHttpClient {
        return try {
            val trustAllCerts = arrayOf<TrustManager>(
                object : X509TrustManager {
                    override fun checkClientTrusted(chain: Array<X509Certificate?>?, authType: String?) {}
                    override fun checkServerTrusted(chain: Array<X509Certificate?>?, authType: String?) {}
                    override fun getAcceptedIssuers(): Array<X509Certificate?>? = arrayOfNulls(0)
                }
            )

            val sslContext = SSLContext.getInstance("SSL")
            sslContext.init(null, trustAllCerts, java.security.SecureRandom())

            val sslSocketFactory = sslContext.socketFactory

            OkHttpClient.Builder()
                .sslSocketFactory(sslSocketFactory, trustAllCerts[0] as X509TrustManager)
                .hostnameVerifier { _, _ -> true }
                .build()
        } catch (e: Exception) {
            throw RuntimeException(e)
        }
    }
}
